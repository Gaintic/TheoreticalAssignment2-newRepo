package atm;

public class MainGUI{
	public static void main(String[] args){
		// TODO Auto-generated method stub
		ATMFrame aFrame=new ATMFrame();
		aFrame.atm.run();
	}

}
