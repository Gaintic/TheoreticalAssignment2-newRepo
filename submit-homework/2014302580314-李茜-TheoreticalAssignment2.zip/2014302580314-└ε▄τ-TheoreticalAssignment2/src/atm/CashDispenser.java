package atm;

//CashDispenser.java
public class CashDispenser {
	//Ĭ�ϳ�ʼֵ
	private final static int INITIAL_COUNT=500;
	private int count;//number of $20 remaining
	
	public CashDispenser()
	{
		count=INITIAL_COUNT;
	}
	
	public void dispenseCash(int amount)
	{
		int billRequired=amount/20;//number of $20 bills required
		count-=billRequired;       //update the count of bills
	}
	
	public boolean isSufficientCashAvailable(int amount)
	{
		int billRequired=amount/20;
		if(count>=billRequired)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
}//������
