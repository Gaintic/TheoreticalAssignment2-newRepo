package atm;

public class Withdrawal extends Transaction{
	
//	private int accountNumber;//�˻�����
	private int amount;    //ȡǮ��Ŀ
	
	//���������
//	private Screen screen;               //ATM's screen
//	private BankDatabase bankDatabase;   //account info database
	private Keypad keypad;               //ATM's keypad
	private CashDispenser cashDispenser; //ATM's cash dispenser

	//constant corresponding to menu option to cancel
	private final static int CANCELED=6;
	
    //���βι��캯��
	public Withdrawal(int userAccountNumber,Screen atmScreen,
			BankDatabase atmBankDatabase,Keypad atmKeypad,
			CashDispenser atmCashDispenser)
	{
		super(userAccountNumber,atmScreen,atmBankDatabase);
		keypad=atmKeypad;
		cashDispenser=atmCashDispenser;
	}
	 
	//��������
	@Override
	public void execute()
	{
		boolean cashDispensed=false;//cash was not dispense yet
		double availableBalance;
		
		BankDatabase bankDatabase=getBankDatabase();
		Screen screen=getScreen();
		
		do
		{
			amount=displayMenuOfAmounts();
			if(amount!=CANCELED)
			{
				availableBalance=
					bankDatabase.getAvailableBalance(getAccountNumber());
				if(amount<=availableBalance)
				{
					if(cashDispenser.isSufficientCashAvailable(amount))
					{
						bankDatabase.debit(getAccountNumber(), amount);
						cashDispenser.dispenseCash(amount);//dispense cash
						cashDispensed=true;//cash was dispensed
						
						screen.displayMessageLine("\nYour cash has been"+
						"dispensed.Please take your cash now.");
					}
					else
					{
						screen.displayMessageLine(
						"\nInsufficient cash available in the ATM."+
						"\n\nPlease choose a smaller amount.");
					}
				}
				else
				{
					screen.displayMessageLine(
						"\nInsufficient funds in your account." +
						"\n\nPlease choose a smaller amount.");
				}
			}
			else
			{
				screen.displayMessageLine("\nCanceling trasaction...");
				return;
			}
		}while(!cashDispensed);
		
	}
	
	private int displayMenuOfAmounts()
	{
		int userChoice=0;
		Screen screen=getScreen();
		
		int[] amount={0,20,40,60,100,200};
		
		while(userChoice==0)
		{
			screen.displayMessageLine("\nWithdrawal Menu:");
			screen.displayMessageLine("1-$20");
			screen.displayMessageLine("2-$40");
			screen.displayMessageLine("3-$60");
			screen.displayMessageLine("4-$100");
			screen.displayMessageLine("5-$200");
			screen.displayMessageLine("6-Canael transaction");
			screen.displayMessage("\nChoose a withdrawal amount:");
			
			int input=keypad.getInput();
			switch(input)
			{
			case 1:
			case 2:
			case 3:
			case 4:
			case 5:
				userChoice=amount[input];
				break;
			case CANCELED:
				userChoice=CANCELED;
				break;
			default:
				screen.displayMessageLine("\nInvalid selection.Try again.");
			}//end switch
		}//end while
		return userChoice;
	}
	
}
