package atm;

//DepositSlot.java

public class DepositSlot {
	//indicate whether envolope was received(always returns true,
	//because this is only a software simulation of a real deposit slot)
	public boolean isEnvelopeReceived()
	{
		return true;
	}
	
}//������
