//Keypad.java
package atm;


public class Keypad {
	public int n;
	public boolean bool=false;
	public Keypad()
	{
	}
	
	public int getInput()
	{
		while(!bool){
			System.out.println("");
		}
		return n;
	}
	
}//�����
