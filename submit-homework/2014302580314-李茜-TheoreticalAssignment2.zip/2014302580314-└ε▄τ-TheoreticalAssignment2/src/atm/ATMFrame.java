package atm;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


import java.io.PrintStream;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class ATMFrame extends JFrame{
	private JFrame atmFrame;
	private String name[]={"1","2","3","4","5","6","7","8","9"};
	private int column[]={20,140,260};                 //������
	private int row[]={280,350,420};                   //������
	private JButton buttons[];
	private JButton buttonEnter;
	private JScrollPane scroll;
	private JLabel takeCashHere;
	private JLabel insertMoney;
	private JLabel background;
	private PrintStream printstream;
	
	public JTextArea displayArea;
	public ATM atm;
	public String input="";
	
	public ATMFrame(){
		atmFrame_initialize();
		buttons_initialize();
		buttonEnter_initialize();
		takeCashPanel_initialize();
		insertMoney_initialize();
		atm=new ATM();
		
		printstream=new PrintStream(System.out){
			public void println(String x){
				displayArea.append(x+"\n");
				displayArea.setCaretPosition(displayArea.getText().length());
			}
			public void print(String x){
				displayArea.append(x);
				displayArea.setCaretPosition(displayArea.getText().length());
			}
			public void print(double x){
				displayArea.append(String.valueOf(x));
				displayArea.setCaretPosition(displayArea.getText().length());
			}
		};
			System.setOut(printstream);
	}
		
	
	
	public void atmFrame_initialize(){
		atmFrame=new JFrame("ATM");
		atmFrame.setVisible(true);
		atmFrame.setSize(800, 600);
		atmFrame.setLayout(null);
		atmFrame.setDefaultCloseOperation(EXIT_ON_CLOSE);
		atmFrame.setBackground(Color.darkGray);
		atmFrame.setResizable(false);
	}
	
	public void displayArea_initialize(){
		displayArea=new JTextArea();
		atmFrame.add(displayArea);
		displayArea.setEditable(false);
		displayArea.setVisible(true);
		displayArea.setBounds(10, 10, 750, 200);
		displayArea.setLineWrap(true);                       //!!!!!!!!!!!!
		displayArea.setFont(new java.awt.Font("Dialog",1,20));
	}
	
	
	
	public void buttons_initialize(){
		buttons=new JButton[9];
		for(int i=0;i<9;i++){
			buttons[i]=new JButton(name[i]);
			atmFrame.add(buttons[i]);
			buttons[i].setBackground(Color.PINK);
			buttons[i].setBounds(column[i%3],row[i/3],100,50);
			String text=buttons[i].getText();
			buttons[i].addActionListener(new ActionListener(){

				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					
					displayArea.append(text);                      //Ϊʲô���������������text��Ч��i��Ч��
					
				}
				
			});
		}
	}
	
	public void buttonEnter_initialize(){
		buttonEnter=new JButton("Enter");
		atmFrame.add(buttonEnter);
		buttonEnter.setBackground(Color.PINK);
		buttonEnter.setBounds(20,490,340,50);
		buttonEnter.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				atm.keypad.n=Integer.parseInt(input);
				atm.keypad.bool=true;
				input="";
			}
		});
	}
	
	public void scroll_initialize(){
		scroll=new JScrollPane();
		atmFrame.add(scroll);
		scroll.setBounds(10,10,750,200);
		scroll.setViewportView(displayArea);
	}
	
	public void takeCashPanel_initialize(){
		ImageIcon P1=new ImageIcon("src/atm/takecashhere.jpg");
		takeCashHere=new JLabel(P1);
		atmFrame.add(takeCashHere);
		takeCashHere.setBounds(420,420,320,100);
	}
	
	public void insertMoney_initialize(){
		ImageIcon P2=new ImageIcon("src/atm/insert.jpg");
		insertMoney=new JLabel(P2);
		atmFrame.add(insertMoney);
		insertMoney.setBounds(420,420,320,100);
	}
	
	
	public void background_initialize(){
		 
		 background = new JLabel();
		 background.setBounds(0, 0,800,600);
		 JPanel backPanel = (JPanel) atmFrame.getContentPane();
		 backPanel.setOpaque(false);
		 atmFrame.getLayeredPane().setLayout(null);
		 atmFrame.getLayeredPane().add(background,new Integer(Integer.MIN_VALUE));
		 backPanel.setLayout(new BorderLayout());
	 }
	
	
	
	
	
	
	
	
	
	
	
}
